#!/bin/sh
#
./qemu-mips -L ./ ./binary
